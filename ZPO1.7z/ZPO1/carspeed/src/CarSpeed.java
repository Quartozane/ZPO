public class CarSpeed implements SpeedCalculationStrategy{

    @Override
    public int calculateMaxSpeed(int car) {
        return car;
    }
}
