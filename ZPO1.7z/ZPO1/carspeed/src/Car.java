public class Car {
    CarName carName;
    SpeedCalculationStrategy speedCalculationStrategy;

    public Car(CarName carName, SpeedCalculationStrategy speedCalculationStrategy) {
        this.carName = carName;
        this.speedCalculationStrategy = speedCalculationStrategy;
    }

    void showSpeed(int speed) {
        System.out.println(speedCalculationStrategy.calculateMaxSpeed(speed));
    }

    void carName(String name) {
        System.out.println(carName.getCarName(name));
    }
}
