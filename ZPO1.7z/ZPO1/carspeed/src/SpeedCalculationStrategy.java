public interface SpeedCalculationStrategy {
    int calculateMaxSpeed(int value);
}
