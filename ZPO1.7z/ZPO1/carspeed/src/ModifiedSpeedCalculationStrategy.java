public class ModifiedSpeedCalculationStrategy implements SpeedCalculationStrategy {
    @Override
    public int calculateMaxSpeed(int value) {
        return value + 10;
    }
}
