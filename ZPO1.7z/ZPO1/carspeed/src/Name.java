public class Name implements CarName{
    @Override
    public String getCarName(String name) {
        return name;
    }
}
