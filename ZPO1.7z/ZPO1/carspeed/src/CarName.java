public interface CarName {
    String getCarName(String name);
}
