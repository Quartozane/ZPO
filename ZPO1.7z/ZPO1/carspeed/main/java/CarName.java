package main.java;

public interface CarName {
    String getName(String name);
}
