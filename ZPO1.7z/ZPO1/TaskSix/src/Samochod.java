public class Samochod implements Dojezdzac{
    @Override
    public void dojezdzac() {
        System.out.println("Dojezdzam samochodem");
    }
}
