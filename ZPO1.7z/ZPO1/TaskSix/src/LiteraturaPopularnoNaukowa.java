public class LiteraturaPopularnoNaukowa implements SpedzanieWolnegoCzasu{
    @Override
    public void spedzajWolnyCzas() {
        System.out.println("Czytam literature popoluarno-naukową");
    }
}
