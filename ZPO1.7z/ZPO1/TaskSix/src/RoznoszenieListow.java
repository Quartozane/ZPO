public class RoznoszenieListow implements  Pracowac{
    @Override
    public void pracuj() {
        System.out.println("Roznosze listy");
    }
}
