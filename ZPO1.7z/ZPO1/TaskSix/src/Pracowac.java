public interface Pracowac {
    void pracuj();
}
