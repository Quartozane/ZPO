public class Rower implements Dojezdzac{
    @Override
    public void dojezdzac() {
        System.out.println("dojezdzam rowerem");
    }
}
