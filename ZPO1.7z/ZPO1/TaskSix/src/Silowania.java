public class Silowania implements SpedzanieWolnegoCzasu{
    @Override
    public void spedzajWolnyCzas() {
        System.out.println("Ide na silownie");
    }
}
