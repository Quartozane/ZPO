public class Pracownik {
    SpedzanieWolnegoCzasu spedzanieWolnegoCzasu;
    Dojezdzac dojezdzac;
    Pracowac pracowac;
    String zawod;

    public Pracownik() {
    }

    public Pracownik(SpedzanieWolnegoCzasu spedzanieWolnegoCzasu, Dojezdzac dojezdzac, Pracowac pracowac, String zawod) {
        this.spedzanieWolnegoCzasu = spedzanieWolnegoCzasu;
        this.dojezdzac = dojezdzac;
        this.pracowac = pracowac;
        this.zawod = zawod;
    }

    public void setSpedzanieWolnegoCzasu(SpedzanieWolnegoCzasu spedzanieWolnegoCzasu) {
        this.spedzanieWolnegoCzasu = spedzanieWolnegoCzasu;
    }

    public void setDojezdzac(Dojezdzac dojezdzac) {
        this.dojezdzac = dojezdzac;
    }

    public void setPracowac(Pracowac pracowac) {
        this.pracowac = pracowac;
    }

    public void performWork(){pracowac.pracuj();}
    public void performTravel(){dojezdzac.dojezdzac();}
    public void performFreeTime(){spedzanieWolnegoCzasu.spedzajWolnyCzas();}
}
