public interface Dojezdzac {
    void dojezdzac();
}
