public class FlyingWithWings implements FlyingBehavior{
    @Override
    public void fly() {
        System.out.println("Duck is flying with wings");
    }
}
