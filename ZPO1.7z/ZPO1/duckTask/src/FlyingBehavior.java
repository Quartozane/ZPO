public interface FlyingBehavior {
    void fly();
}
