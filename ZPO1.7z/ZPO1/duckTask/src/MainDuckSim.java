import java.util.ArrayList;

public class MainDuckSim {
    public static void main(String[] args){
        ArrayList<Duck> ducks = new ArrayList<>();
        ducks.add(new MallardDuck(new FlyingWithWings(),new Quack()));
        ducks.add(new RubberDuck(new FlyingNoWay(),new Squeak()));
        ducks.add(new ModelDuck(new FlyingNoWay(), new MuteQuack()));
        Duck duck1 = new MallardDuck(new FlyingWithWings(),new Quack());
        duck1.performFly();
        duck1.performQuack();

        for(Duck duck:ducks) {
            duck.performQuack();
            duck.performFly();
        }

        ducks.get(1).setFlyingBehavior(new FlyingBehavior() {
            @Override
            public void fly() {
                System.out.println("Duck is flying with jetpack");
            }
        });
        ducks.get(1).performFly();
    }
}
