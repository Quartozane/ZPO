public interface QuackBehavior {

    void Quack();
}
