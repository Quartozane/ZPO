public class Main {
    public static void main(String[] args) {
        TaxCalculator taxCalculator = new TaxCalculator(new PolandTaxCalculationStrategy());
        double taxAmount = taxCalculator.calculateTax(100);
        System.out.println("Podatek do zapłaty: " + taxAmount);
    }
}