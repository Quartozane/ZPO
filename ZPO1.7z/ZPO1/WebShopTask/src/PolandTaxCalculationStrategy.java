public class PolandTaxCalculationStrategy implements TaxCalculationStrategy {
    @Override
    public double calculateTax(double amount) {
        return amount * 0.23;
    }
}
