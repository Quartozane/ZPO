public class GermanyTaxCalculationStrategy implements TaxCalculationStrategy {
    @Override
    public double calculateTax(double amount) {
        return amount * 0.19;
    }
}
