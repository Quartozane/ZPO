public interface TaxCalculationStrategy {
    double calculateTax(double amount);
}
