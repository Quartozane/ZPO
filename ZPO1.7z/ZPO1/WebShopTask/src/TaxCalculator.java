public class TaxCalculator {
    private TaxCalculationStrategy taxCalculationStrategy;

    public TaxCalculator(TaxCalculationStrategy taxCalculationStrategy) {
        this.taxCalculationStrategy = taxCalculationStrategy;
    }

    public void setTaxCalculationStrategy(TaxCalculationStrategy taxCalculationStrategy) {
        this.taxCalculationStrategy = taxCalculationStrategy;
    }

    public double calculateTax(double amount) {
        return taxCalculationStrategy.calculateTax(amount);
    }
}
