public class UKTaxCalculationStrategy implements TaxCalculationStrategy {
    @Override
    public double calculateTax(double amount) {
        return amount * 0.20;
    }
}
